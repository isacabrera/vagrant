from flask import Flask, request, jsonify
import mysql.connector

app = Flask(__name__)

db_config = {
    'database': 'datadb',
    'user': 'isabel',
    'password': 'isabel',
    'host': '192.168.56.11'
}
def guardar():
    try:
        con = mysql.connector.connect(**db_config)
        cursor = con.cursor()

        data = request.get_json()
        nombre = data.get('nombre')
        apellido = data.get('apellido')

        consulta = 'INSERT INTO form (nombre, apellido) VALUES (%s, %s);'
        info = (nombre, apellido)
        cursor.execute(consulta, info)

        con.commit()

        return jsonify({'mensaje': 'Datos insertados correctamente'}), 201

    except Exception as err:
        print("Error:", str(err))
        return jsonify({"Error": "Error al insertar datos en la base de datos"}), 500

    finally:
        if con:
           con.close()

def obtener():
    try:
        con = mysql.connector.connect(**db_config)
        cursor = con.cursor()
        
        cursor.execute("SELECT * FROM form;")
        resultados = cursor.fetchall()

        info = [{"nombre": row[1], "apellido": row[2]} for row in resultados]
        return jsonify({"data": info})

    except Exception as err:
        print("Error:", str(err))
        return jsonify({"Error": "Error al obtener datos de la base de datos"}), 500

@app.route("/form", methods=["GET", "POST"])
def form():
    if request.method == "GET":
        return obtener()
    elif request.method == "POST":
        return guardar()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)

